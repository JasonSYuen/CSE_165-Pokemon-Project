#include <iostream>
#include <string>
#include <vector>
#include "../BasePokemon.h"
#pragma once

using namespace std;

class Vileplume : public Pokemon
{

public:
    Vileplume()
    {
        (this->type).push_back("grass");
        (this->type).push_back("poison");
        this->name = "Vileplume";
        this->hp = 75;
        this->atk = 80;
        this->def = 85;
        this->sp_atk = 110;
        this->sp_def = 90;
        this->speed = 50;

        this->MyMove1_name = "sleep_powder";
        this->MyMove2_name = "stun_spore";
        this->MyMove3_name = "body_slam";
        this->MyMove4_name = "razor_leaf";

        this->base_hp = 75;
        this->base_atk = 80;
        this->base_speed = 50;
    };

    void speak() override
    {
        cout << name << endl;
    }

    container move1() override
    {
        return sleep_powder();
    }
    container move2() override
    {
        return stun_spore();
    }
    container move3() override
    {
        return body_slam(atk);
    }
    container move4() override
    {
        return razor_leaf(sp_atk);
    }

    void print_moves() override
    {
        cout << "sleep_powder\n"
             << "stun_spore\n"
             << "body_slam\n"
             << "razor_leaf\n";
    }
};
