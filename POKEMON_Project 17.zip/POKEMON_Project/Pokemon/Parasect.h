#include <iostream>
#include <string>
#include <vector>
#include "../BasePokemon.h"
#pragma once

using namespace std;

class Parasect : public Pokemon
{
public:
    Parasect()
    {
        (this->type).push_back("bug");
        (this->type).push_back("grass");
        this->name = "Parasect";
        this->hp = 60;
        this->atk = 95;
        this->def = 80;
        this->sp_atk = 60;
        this->sp_def = 80;
        this->speed = 30;

        this->MyMove1_name = "swords_dance";
        this->MyMove2_name = "hyper_beam";
        this->MyMove3_name = "spore";
        this->MyMove4_name = "stun_spore";

        this->base_hp = 60;
        this->base_atk = 95;
        this->base_speed = 30;
    };

    void speak() override
    {
        cout << name << endl;
    }

    container move1() override
    {
        return swords_dance();
    }
    container move2() override
    {
        return hyper_beam(atk);
    }
    container move3() override
    {
        return spore();
    }
    container move4() override
    {
        return stun_spore();
    }
    void print_moves() override
    {
        cout << "swords_dance\n"
             << "hyper_beam\n"
             << "spore\n"
             << "stun_spore\n";
    }
};
