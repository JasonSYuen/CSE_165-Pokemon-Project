#include <iostream>
#include <string>
#include <vector>
#include "../BasePokemon.h"
#pragma once

using namespace std;

class Squirtle : public Pokemon
{

public:
    Squirtle()
    {
        (this->type).push_back("water");
        this->name = "Squirtle";
        this->hp = 44;
        this->atk = 48;
        this->def = 65;
        this->sp_atk = 50;
        this->sp_def = 64;
        this->speed = 43;
        this->MyMove1_name = "blizzard";
        this->MyMove2_name = "surf";
        this->MyMove3_name = "body_slam";
        this->MyMove4_name = "recover";

        this->base_hp = 44;
        this->base_atk = 48;
        this->base_speed = 43;
    };

    void speak() override
    {
        cout << name << endl;
    }

    container move1() override
    {
        return blizzard(sp_atk);
    }
    container move2() override
    {
        return surf(sp_atk);
    }
    container move3() override
    {
        return body_slam(atk);
    }
    container move4() override
    {
        return recover();
    }
    void print_moves() override
    {
        cout << "blizzard\n"
             << "surf\n"
             << "body_slam\n"
             << "recover\n";
    }
};
