#include <iostream>
#include <string>
#include <vector>
#include "../BasePokemon.h"
#pragma once

using namespace std;

class Tangela : public Pokemon
{

public:
    Tangela()
    {
        (this->type).push_back("grass");
        this->name = "Tangela";
        this->hp = 65;
        this->atk = 55;
        this->def = 115;
        this->sp_atk = 100;
        this->sp_def = 40;
        this->speed = 60;

        this->MyMove1_name = "sleep_powder";
        this->MyMove2_name = "stun_spore";
        this->MyMove3_name = "body_slam";
        this->MyMove4_name = "recover";

        this->base_hp = 65;
        this->base_atk = 55;
        this->base_speed = 60;
    };

    void speak() override
    {
        cout << name << endl;
    }

    container move1() override
    {
        return sleep_powder();
    }
    container move2() override
    {
        return stun_spore();
    }
    container move3() override
    {
        return body_slam(atk);
    }
    container move4() override
    {
        return recover();
    }

    void print_moves() override
    {
        cout << "sleep_powder\n"
             << "stun_spore\n"
             << "body_slam\n"
             << "recover\n";
    }
};
