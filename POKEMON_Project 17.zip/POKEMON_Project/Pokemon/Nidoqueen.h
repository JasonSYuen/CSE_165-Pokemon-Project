#include <iostream>
#include <string>
#include <vector>
#include "../BasePokemon.h"
#pragma once

using namespace std;

class Nidoqueen : public Pokemon
{
public:
    Nidoqueen()
    {
        (this->type).push_back("poison");
        (this->type).push_back("ground");
        this->name = "Nidoqueen";
        this->hp = 90;
        this->atk = 92;
        this->def = 87;
        this->sp_atk = 75;
        this->sp_def = 85;
        this->speed = 76;
        this->MyMove1_name = "earthquake";
        this->MyMove2_name = "thunderbolt";
        this->MyMove3_name = "blizzard";
        this->MyMove4_name = "fire_blast";

        this->base_hp = 90;
        this->base_atk = 92;
        this->base_speed = 76;
    };

    void speak() override
    {
        cout << name << endl;
    }

    container move1() override
    {
        return earthquake(atk);
    }
    container move2() override
    {
        return thunderbolt(sp_atk);
    }
    container move3() override
    {
        return blizzard(sp_atk);
    }
    container move4() override
    {
        return fire_blast(sp_atk);
    }

    void print_moves() override
    {
        cout << "earthquake\n"
             << "thunderbolt\n"
             << "blizzard\n"
             << "fire_blast\n";
    }
};
