#include <iostream>
#include <string>
#include <vector>
#include "../BasePokemon.h"
#pragma once

using namespace std;

class Dragonite : public Pokemon
{

public:
    Dragonite()
    {
        (this->type).push_back("dragon");
        (this->type).push_back("flying");
        this->name = "Dragonite";
        this->hp = 91;
        this->atk = 134;
        this->def = 95;
        this->sp_atk = 100;
        this->sp_def = 100;
        this->speed = 80;
        this->MyMove1_name = "agility";
        this->MyMove2_name = "blizzard";
        this->MyMove3_name = "body_slam";
        this->MyMove4_name = "thunderbolt";

        this->base_hp = 91;
        this->base_atk = 134;
        this->base_speed = 80;
    };

    void speak() override
    {
        cout << name << endl;
    }

    container move1() override
    {
        return agility();
    }
    container move2() override
    {
        return blizzard(sp_atk);
    }
    container move3() override
    {
        return body_slam(atk);
    }
    container move4() override
    {
        return thunderbolt(sp_atk);
    }

    void print_moves() override
    {
        cout << "agility\n"
             << "blizzard\n"
             << "body_slam\n"
             << "thunderbolt\n";
    }
};
