#include <iostream>
#include <string>
#include <vector>
#include "../BasePokemon.h"
#pragma once

using namespace std;

class Moltres : public Pokemon
{
public:
    Moltres()
    {
        (this->type).push_back("fire");
        (this->type).push_back("flying");
        this->name = "Moltres";
        this->hp = 90;
        this->atk = 100;
        this->def = 90;
        this->sp_atk = 125;
        this->sp_def = 85;
        this->speed = 90;

        this->MyMove1_name = "fire_blast";
        this->MyMove2_name = "hyper_beam";
        this->MyMove3_name = "peck";
        this->MyMove4_name = "agility";

        this->base_hp = 90;
        this->base_atk = 100;
        this->base_speed = 90;
    };

    void speak() override
    {
        cout << name << endl;
    }

    container move1() override
    {
        return fire_blast(sp_atk);
    }
    container move2() override
    {
        return hyper_beam(atk);
    }
    container move3() override
    {
        return peck(atk);
    }
    container move4() override
    {
        return agility();
    }

    void print_moves() override
    {
        cout << "fire_blast\n"
             << "hyper_beam\n"
             << "peck\n"
             << "agility\n";
    }
};
