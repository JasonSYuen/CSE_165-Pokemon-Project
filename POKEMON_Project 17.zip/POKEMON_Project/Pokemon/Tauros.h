#include <iostream>
#include <string>
#include <vector>
#include "../BasePokemon.h"
#pragma once

using namespace std;

class Tauros : public Pokemon
{
public:
    Tauros()
    {
        (this->type).push_back("normal");
        this->name = "Tauros";
        this->hp = 75;
        this->atk = 100;
        this->def = 95;
        this->sp_atk = 40;
        this->sp_def = 70;
        this->speed = 110;

        this->MyMove1_name = "blizzard";
        this->MyMove2_name = "body_slam";
        this->MyMove3_name = "earthquake";
        this->MyMove4_name = "hyper_beam";

        this->base_hp = 75;
        this->base_atk = 100;
        this->base_speed = 110;
    };

    void speak() override
    {
        cout << name << endl;
    }

    container move1() override
    {
        return blizzard(sp_atk);
    }
    container move2() override
    {
        return body_slam(atk);
    }
    container move3() override
    {
        return earthquake(atk);
    }
    container move4() override
    {
        return hyper_beam(atk);
    }

    void print_moves() override
    {
        cout << "blizzard\n"
             << "body_slam\n"
             << "earthquake\n"
             << "hyper_beam\n";
    }
};
