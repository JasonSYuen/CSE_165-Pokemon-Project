#include <iostream>
#include <string>
#include <vector>
#include "../BasePokemon.h"
#pragma once

using namespace std;

class Nidoking : public Pokemon
{
public:
    Nidoking()
    {
        (this->type).push_back("poison");
        (this->type).push_back("ground");
        this->name = "Nidoking";
        this->hp = 81;
        this->atk = 102;
        this->def = 77;
        this->sp_atk = 85;
        this->sp_def = 75;
        this->speed = 85;

        this->MyMove1_name = "earthquake";
        this->MyMove2_name = "thunderbolt";
        this->MyMove3_name = "blizzard";
        this->MyMove4_name = "rock_slide";

        this->base_hp = 81;
        this->base_atk = 102;
        this->base_speed = 85;
    };

    void speak() override
    {
        cout << name << endl;
    }

    container move1() override
    {
        return earthquake(atk);
    }
    container move2() override
    {
        return thunderbolt(sp_atk);
    }
    container move3() override
    {
        return blizzard(sp_atk);
    }
    container move4() override
    {
        return rock_slide(atk);
    }

    void print_moves() override
    {
        cout << "earthquake\n"
             << "thunderbolt\n"
             << "blizzard\n"
             << "rock_slide\n";
    }
};
