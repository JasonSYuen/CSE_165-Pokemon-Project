#include <iostream>
#include <string>
#include <vector>
#include <stdlib.h>
#include <time.h>
// #include <unistd.h>
using namespace std;

#pragma once

class updated_moves
{
public:
    string name;
    int basepower;
    string special_or_not;
    string damagetype;
    string status;
    int accuracy;
    int accuracy2;
    string description;

    struct container
    {
        int total_attack_damage;
        string special_or_not;
        string damagetype;
        string status;
        string name;
    };

    void fill_values(int bp, string sp, string type, string effect, int acc, int acc2, string name, string desc)
    {
        this->basepower = bp;
        this->special_or_not = sp;
        this->damagetype = type;
        this->status = effect;
        this->accuracy = acc;
        this->accuracy2 = acc2;
        this->name = name;
        this->description = desc;
    }

    container fill_return(int pp, int atk, string sp, string type, string effect)
    {
        container x;
        x.total_attack_damage = pp * atk;
        x.special_or_not = sp;
        x.damagetype = type;
        x.status = effect;
        x.name = this->name;
        return x;
    }

    container fill_return(string miss)
    {
        container x;
        x.total_attack_damage = 0;
        x.special_or_not = "none";
        x.damagetype = "none";
        x.status = "miss";
        x.name = this->name;
        return x;
    }

    bool success(int Chance_Success)
    {
        int x = rand() % 100 + 1;
        if (x <= Chance_Success)
        {
            return true;
        }
        else
            return false;
    }

    vector<string> desc()
    {

        string arr[7] = {this->name, to_string(this->basepower), this->special_or_not, this->damagetype, to_string(this->accuracy), this->description};
        vector<string> v;
        v.insert(v.end(), begin(arr), end(arr));

        return v;
    }

    container activate(int sp_atk_or_atk)
    {

        if (success(this->accuracy) == true)
        {
            if (success(this->accuracy2) == true)
            {
                return fill_return(this->basepower, sp_atk_or_atk, this->special_or_not, this->damagetype, this->status);
            }
            else
            {
                return fill_return(this->basepower, sp_atk_or_atk, this->special_or_not, this->damagetype, "none");
            }
        }
        return fill_return("miss");
    }

    container activate()
    {
        if (success(this->accuracy) == true)
        {
            if (success(this->accuracy2) == true)
            {
                return fill_return(this->basepower, 0, this->special_or_not, this->damagetype, this->status);
            }
            else
            {
                return fill_return(this->basepower, 0, this->special_or_not, this->damagetype, "none");
            }
        }
        return fill_return("miss");
    }
};
