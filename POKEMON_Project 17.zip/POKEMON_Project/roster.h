#include <iostream>

#include <vector>
#include <typeinfo>
#include "BasePokemon.h"
#pragma once
class Roster
{
public:
    vector<Pokemon *> listOfPokemon;
    int num_alive;
    Roster()
    {
    }

    void add(Pokemon *p)
    {
        listOfPokemon.push_back(p);
        num_alive += 1;
    }

    void print()
    {
        for (int i = 0; i < listOfPokemon.size(); i++)
        {
            cout << i << " : ";
            listOfPokemon[i]->speak();
        }
    }

    Pokemon *view(int place_in_vector)
    {
        return (listOfPokemon[place_in_vector]);
    }
};