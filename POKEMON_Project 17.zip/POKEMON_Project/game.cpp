
#include <iostream>
#include "IncludeEverything.h"
#include "trainer.h"
#include "type_matchup.h"
#include <vector>

int damage_calc(string sp_or_not, float damage, string damage_type, Pokemon *def_poke)
{
    type_matchup_sheet *sheet = new type_matchup_sheet();
    vector<string> vec_types = def_poke->type;
    string defender_type1;
    string defender_type2;

    float type_bonus;
    float def;
    if (vec_types.size() == 1)
    {
        defender_type1 = vec_types[0];
        type_bonus = (*sheet).fix_type(damage_type, defender_type1);
    }
    else
    {
        defender_type1 = vec_types[0];
        defender_type1 = vec_types[1];
        type_bonus = (*sheet).fix_type(damage_type, defender_type1, defender_type2);
    }

    if (sp_or_not == "physical")
    {
        def = (*def_poke).def;
    }
    else
    {
        def = (*def_poke).sp_def;
    }
    // cout << def << endl;
    // cout << (damage / def) << endl;
    float x = ((((5) * (damage / def)) / (50)) + 2) * type_bonus;
    return x;
}
void simulate_combat(trainer *attacking, trainer *defending, int currentPokemonAttack, int currentPokemonDefend, int moveNum)
{
    // cout << "yo" << endl;
    if (moveNum == 0)
    {
    }
    else
    {
        // cout << "yo";
        auto result_of_attack = (((*attacking).r.view(currentPokemonAttack)))->move_num(moveNum); // makes sure function is only called once
        // cout << "as";
        //  check miss
        cout << (((*attacking).r.view(currentPokemonAttack)))->name << " uses " << result_of_attack.name << endl;
        if (result_of_attack.status == "miss")
        {
            cout << "attack missed" << endl;
        }
        // check if status move
        // check if damage
        else
        {

            // implement status ie defending pokemon.status =  result_of_attack.status if the status is burn para, poison
            int dmg = damage_calc(result_of_attack.special_or_not, result_of_attack.total_attack_damage, result_of_attack.damagetype, (*defending).r.view(currentPokemonDefend));
            if (result_of_attack.special_or_not != "non damaging")
            {
                (((*defending).r.view(currentPokemonDefend)->hp)) = (((*defending).r.view(currentPokemonDefend)->hp)) - dmg;
                cout << (((*defending).r.view(currentPokemonDefend)))->name << " has taken " << dmg << " points of damage" << endl;
                // cout << "combat simulated" << endl;
            }

            cout << "status inflicted : " << result_of_attack.status << endl;
            if (result_of_attack.status == "double speed")
            {
                cout << "speed doubled" << endl;
                (((*attacking).r.view(currentPokemonAttack)))->speed = (((*attacking).r.view(currentPokemonAttack)))->speed * 2;
            }

            if (result_of_attack.status == "double sp_atk")
            {
                cout << "sp_atk doubled" << endl;
                (((*attacking).r.view(currentPokemonAttack)))->sp_atk = (((*attacking).r.view(currentPokemonAttack)))->sp_atk * 2;
            }
            if (result_of_attack.status == "double atk")
            {
                cout << "atk doubled" << endl;
                (((*attacking).r.view(currentPokemonAttack)))->atk = (((*attacking).r.view(currentPokemonAttack)))->atk * 2;
            }
            if (result_of_attack.status == "sleep" || result_of_attack.status == "freeze" || result_of_attack.status == "paralyze" || result_of_attack.status == "burn" || result_of_attack.status == "poison")
            {
                cout << result_of_attack.status << " has been inflicted on defending Pokemon" << endl;
                (((*defending).r.view(currentPokemonDefend)->status)) = result_of_attack.status;
            }

            if (result_of_attack.status == "recoil")
            {
                cout << "Attacking pokemon has taken " << dmg / 4 << " recoil damage" << endl;
                (((*attacking).r.view(currentPokemonAttack)->hp)) = (((*attacking).r.view(currentPokemonAttack)->hp)) - dmg / 4;
                // recoil bug if killed by recoil
            }

            if (result_of_attack.status == "suicide")
            {
                cout << "Attacking pokemon faints" << endl;
                (((*attacking).r.view(currentPokemonAttack)->hp)) = 0;
            }
            if (result_of_attack.status == "skip next turn")
            {
                // idk maybe put another var to know if turn needs to be skipped   ############################
                ((*attacking).r.view(currentPokemonAttack))->status = "sleep";
                // cout
                cout << ((*attacking).r.view(currentPokemonAttack))->name << " fell asleep" << endl;
            }

            if (result_of_attack.status == "lower enemy sp_def")
            {
                cout << result_of_attack.status << " has been inflicted on defending Pokemon" << endl;
                (((*defending).r.view(currentPokemonDefend)->sp_def)) = (((*defending).r.view(currentPokemonDefend)->sp_def)) / 2;
            }

            if (result_of_attack.status == "heal 50")
            {
                // I will Fix this later would need to change a bunch #######################

                (((*attacking).r.view(currentPokemonAttack)->hp)) += (((*attacking).r.view(currentPokemonAttack)->base_hp)) / 2;

                if ((((*attacking).r.view(currentPokemonAttack)->hp)) > (((*attacking).r.view(currentPokemonAttack)->base_hp)))
                {
                    (((*attacking).r.view(currentPokemonAttack)->hp)) = (((*attacking).r.view(currentPokemonAttack)->base_hp));
                }

                cout << (*attacking).r.view(currentPokemonAttack)->name << " heals " << (((*attacking).r.view(currentPokemonAttack)->base_hp)) / 2 << endl;
            }
        }
    }
}

int check_status(Pokemon *poke, int orig)
{
    if (poke->speed == poke->base_speed / 2)
    {
        poke->speed = poke->base_speed;
    }

    if (poke->atk == poke->base_atk / 2)

    {
        poke->atk = poke->base_atk; // swords dance might mess up;
    }

    if (poke->status == "sleep")
    {
        cout << poke->name << " is asleep" << endl;

        int x = rand() % 100 + 1;
        if (x < 40)
        {
            cout << poke->name << " woke up!" << endl;
            poke->status = "none";
            return orig;
        }
        return 0;

        // skip next turn implementation
    }
    if (poke->status == "freeze")
    {
        cout << poke->name << " is frozen" << endl;

        int x = rand() % 100 + 1;
        if (x < 30)
        {
            cout << poke->name << " unfroze!" << endl;
            poke->status = "none";
            return orig;
        }
        return 0;
        // skip next turn implementation
    }
    if (poke->status == "paralyze")
    {
        int x = rand() % 100 + 1;
        (poke)->speed = (poke)->base_speed / 2; ///
        cout << "paralyzed: speed halved" << endl;
        if (x < 30)
        {
            cout << poke->name << " is paralyzed" << endl;
            return 0;
        }
        else
        {
            return orig;
        }

        // speed modifier = .5
    }
    if (poke->status == "burn")
    {
        (poke)->atk = (poke)->base_atk / 2; ///

        cout << "burned: atk halved" << endl;
        cout << poke->name << " is burned and takes 5 damage" << endl;
        poke->hp = poke->hp - 5;
        if (poke->hp <= 0)
        {
            poke->hp = 1;
            cout << "Can't be killed by burn" << endl;
        }

        return orig;
        // atk modifier = .5
        // take 5? damage
    }
    if (poke->status == "poison")
    {
        cout << poke->name << " is poisoned" << endl;
        cout << poke->name << " is poisoned and takes 5 damage" << endl;
        poke->hp = poke->hp - 5;
        if (poke->hp <= 0)
        {
            poke->hp = 1;
            cout << "Can't be killed by poison" << endl;
        }
        // take 5? damage
        return orig;
    }

    return orig;
}

int check_alive(trainer *trainer, Pokemon *poke)
{
    if (poke->hp > 0)
    {
        // alive
        return 0;
    }
    else
    {
        // dead
        cout << poke->name << " has fainted!\n";

        (*trainer).r.num_alive -= 1;
        if ((*trainer).r.num_alive == 0)
        {
            return 1;
        }

        else
        {
            return 2; // if 2 swap
        }
        return 0;
    }
}

int swap(trainer *trainer)
{

    int currentPokemon = -1;
    if (trainer->name == "USER")
    {
        cout << "what pokemon would you like to switch to" << endl;
        (*trainer).r.print();

        while (currentPokemon == -1)
        {
            cin >> currentPokemon;
            if (currentPokemon >= 3 || currentPokemon < 0)
            {
                cout << "No pokemon there" << endl;
                currentPokemon = -1;
            }
            else if ((*trainer).r.view(currentPokemon)->hp <= 0)
            {
                cout << "that Pokemon has already fainted, pick another" << endl;
                currentPokemon = -1;
            }
        }

        cout << (*trainer).name << " sends out " << (*trainer).r.view(currentPokemon)->name;
        cout << endl;
        return currentPokemon;
    }
    else
    {
        //(*trainer).r.print();
        while (currentPokemon == -1)
        {
            currentPokemon = rand() % 3; // teams of 3
            if ((*trainer).r.view(currentPokemon)->hp <= 0)
            {
                // cout << "that Pokemon has already fainted, pick another" << endl;
                currentPokemon = -1;
            }
        }
        cout << (*trainer).name << " sends out " << (*trainer).r.view(currentPokemon)->name << endl;
        return currentPokemon;
    }
}

int main()
{
    srand(time(NULL)); // makes srand

    trainer *user = new trainer("USER"); // make trainer   (trainers are pretty much just rosters)  // note User must be named USER
                                         // add pokemon to trainer roster

    trainer *ai = new trainer("AI");
    // users team:
    Charmander *charmander = new Charmander(); // make a charmander
    Squirtle *squirtle = new Squirtle();
    Parasect *parasect = new Parasect();
    (*user).r.add(charmander);
    (*user).r.add(squirtle);
    (*user).r.add(parasect);

    // AI team
    Bulbasaur *b = new Bulbasaur();
    Tangela *tangela = new Tangela();
    Beedrill *beedrill = new Beedrill();

    (*ai).r.add(b); // add pokemon to trainer roster
    (*ai).r.add(tangela);
    (*ai).r.add(beedrill);

    // cout << (*user).r.num_alive << endl;
    //(*ai).r.print();
    int gameEnd = 0;
    int currentPokemonUser = 0; // index of the active pokemon in the roster of user
    int currentPokemonAI = 0;   // index of the active pokemon in the roster of AI
    int userChoice = 0;         // what the user wants to do
    int validChoice = 0;        // verifies user input
    int selectedMove = 0;
    int selectedMoveAI = 0;

    cout << "################################" << endl;

    cout << (*ai).name << " sends out " << (*ai).r.view(currentPokemonAI)->name;
    cout << endl;

    cout << (*user).name << " sends out " << (*user).r.view(currentPokemonUser)->name;
    cout << endl;

    while (gameEnd != 1)
    { // game will only end when this value is set to 1

        cout << "################################" << endl;
        cout << endl;
        cout << "User Pokemon: " << (*user).r.view(currentPokemonUser)->name << " HP: " << (*user).r.view(currentPokemonUser)->hp << endl;
        cout << "AI Pokemon: " << (*ai).r.view(currentPokemonAI)->name << " HP: " << (*ai).r.view(currentPokemonAI)->hp << endl;
        cout << endl;

        cout << "What would you like to do?" << endl;
        cout << "1. Attack" << endl;
        cout << "2. Switch Pokemon" << endl;
        cin >> userChoice;

        cout << "################################" << endl;
        // cout << endl;

        while (validChoice != 1)
        {
            validChoice = 1;
            if (userChoice == 1)
            {

                // cout << "attack list: " << endl;

                (((*user).r.view(currentPokemonUser)->print_moves()));

                cout << "Which move would you like to use?" << endl;
                cout << "Move ";
                cin >> selectedMove;
                // select chosen attack
            }
            else if (userChoice == 2)
            { // switch pokemon option
              // validChoice = 0;
                selectedMove = 0;
                currentPokemonUser = swap(user);
            }
            else
            {
                validChoice = 0;
                cin >> userChoice;
            }
            selectedMoveAI = rand() % 4 + 1;
        }
        validChoice = 0;

        // cout << currentPokemonAI << endl;
        cout << endl;
        cout << "################################" << endl;

        if ((((*user).r.view(currentPokemonUser)->speed)) > (((*ai).r.view(currentPokemonAI)->speed)))
        {

            selectedMove = check_status((*user).r.view(currentPokemonUser), selectedMove);

            simulate_combat(user, ai, currentPokemonUser, currentPokemonAI, selectedMove);

            gameEnd = check_alive(ai, (*ai).r.view(currentPokemonAI));

            cout << endl;

            if (gameEnd == 2)
            {
                currentPokemonAI = swap(ai);
            }

            if (gameEnd == 0)
            {

                selectedMoveAI = check_status((*ai).r.view(currentPokemonAI), selectedMoveAI);
                simulate_combat(ai, user, currentPokemonAI, currentPokemonUser, selectedMoveAI);
                gameEnd = check_alive(user, (*user).r.view(currentPokemonUser));
                cout << endl;

                if (gameEnd == 2)
                {
                    currentPokemonUser = swap(user);
                }
            }
        }
        else
        {

            selectedMoveAI = check_status((*ai).r.view(currentPokemonAI), selectedMoveAI);
            simulate_combat(ai, user, currentPokemonAI, currentPokemonUser, selectedMoveAI);
            gameEnd = check_alive(user, (*user).r.view(currentPokemonUser));

            cout << endl;

            if (gameEnd == 2)
            {
                currentPokemonUser = swap(user);
            }

            if (gameEnd == 0)
            {
                //
                selectedMove = check_status((*user).r.view(currentPokemonUser), selectedMove);
                simulate_combat(user, ai, currentPokemonUser, currentPokemonAI, selectedMove);
                gameEnd = check_alive(ai, (*ai).r.view(currentPokemonAI));
                cout << endl;

                if (gameEnd == 2)
                {

                    currentPokemonAI = swap(ai);
                    // cout << currentPokemonAI << endl;
                }
                // cout << "hellp" << endl;
            }
        }

        // - implement enemy attack choice
        // - calculate the damage dealt to the slower pokemon
        // - if the slower pokemon lives, deal the damage to the faster pokemon
        // - if the slower pokemon faints, check if there are any remaining pokemon (FOR NOW FAINTING MEANS DELETING THE POKEMON FROM THE ROSTER)
        // - if there are remaining pokemon, give the user the option to choose from them
    }

    if ((*user).r.num_alive == 0)
    {
        cout << "you lose try again next time" << endl;
    }
    else
    {
        cout << "You win, try again?";
    }

    return 1;
};
