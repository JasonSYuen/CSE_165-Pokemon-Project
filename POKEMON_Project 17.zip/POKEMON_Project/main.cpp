
#include <iostream>
#include "IncludeEverything.h"
#include "trainer.h"
#include <vector>
#include "moves/combined_moves.h"
using namespace std;

void simulate_combat(trainer *attacking, trainer *defending, int currentPokemonAttack, int currentPokemonDefend, int moveNum)
{

    auto result_of_attack = (((*attacking).r.view(currentPokemonAttack)))->move_num(moveNum); // makes sure function is only called once
    // check miss
    cout << (((*attacking).r.view(currentPokemonAttack)))->name << " uses " << result_of_attack.name << endl;
    if (result_of_attack.status == "miss")
    {
        cout << "attack missed" << endl;
    }
    // check if status move
    // check if damage
    else
    {
        (((*defending).r.view(currentPokemonDefend)->hp)) = (((*defending).r.view(currentPokemonDefend)->hp)) - (result_of_attack.total_attack_damage / (10 * (((*defending).r.view(currentPokemonDefend)->def))));
        // implement status ie defending pokemon.status =  result_of_attack.status if the status is burn para, poison
        if (result_of_attack.special_or_not != "non damaging")
        {
            cout << (((*defending).r.view(currentPokemonDefend)))->name << " has taken " << (result_of_attack.total_attack_damage / (10 * (((*defending).r.view(currentPokemonDefend)->def)))) << " points of damage" << endl;
            cout << "combat simulated" << endl;
        }

        cout << "status inflicted : " << result_of_attack.status << endl;
        if (result_of_attack.status == "double speed")
        {
            cout << "speed doubled" << endl;
            (((*attacking).r.view(currentPokemonAttack)))->speed = (((*attacking).r.view(currentPokemonAttack)))->speed * 2;
        }

        if (result_of_attack.status == "double sp_atk")
        {
            cout << "sp_atk doubled" << endl;
            (((*attacking).r.view(currentPokemonAttack)))->sp_atk = (((*attacking).r.view(currentPokemonAttack)))->sp_atk * 2;
        }
        if (result_of_attack.status == "double atk")
        {
            cout << "atk doubled" << endl;
            (((*attacking).r.view(currentPokemonAttack)))->atk = (((*attacking).r.view(currentPokemonAttack)))->atk * 2;
        }
        if (result_of_attack.status == "sleep" || result_of_attack.status == "freeze" || result_of_attack.status == "paralyze" || result_of_attack.status == "burn" || result_of_attack.status == "poison")
        {
            cout << result_of_attack.status << " has been inflicted on defending Pokemon" << endl;
            (((*defending).r.view(currentPokemonDefend)->status)) = result_of_attack.status;
        }

        if (result_of_attack.status == "recoil")
        {
            cout << "Attacking pokemon has taken recoil damage" << endl;
            (((*attacking).r.view(currentPokemonAttack)->hp)) = (result_of_attack.total_attack_damage / (10 * (((*defending).r.view(currentPokemonDefend)->def)))) / 4;
        }

        if (result_of_attack.status == "suicide")
        {
            cout << "Attacking pokemon faints" << endl;
            (((*attacking).r.view(currentPokemonAttack)->hp)) = 0;
        }
        if (result_of_attack.status == "skip_next_turn")
        {
            // idk maybe put another var to know if turn needs to be skipped   ############################
            cout << "status not implemented yet" << endl;
        }

        if (result_of_attack.status == "lower enemy sp_def")
        {
            cout << result_of_attack.status << " has been inflicted on defending Pokemon" << endl;
            (((*defending).r.view(currentPokemonDefend)->sp_def)) = (((*defending).r.view(currentPokemonDefend)->sp_def)) / 2;
        }

        if (result_of_attack.status == "heal 50")
        {
            // I will Fix this later would need to change a bunch #######################
            cout << "status not implemented yet" << endl;
        }
    }
}

void check_status(Pokemon *poke)
{
    if (poke->status == "sleep")
    {
        cout << poke->name << " is asleep" << endl;
        // skip next turn implementation
    }
    if (poke->status == "freeze")
    {
        cout << poke->name << " is frozen" << endl;
        // skip next turn implementation
    }
    if (poke->status == "paralyze")
    {
        cout << poke->name << " is paralyzed" << endl;
        // speed modifier = .5
    }
    if (poke->status == "burn")
    {
        cout << poke->name << " is burned" << endl;
        // atk modifier = .5
        // take 5? damage
    }
    if (poke->status == "poison")
    {
        cout << poke->name << " is burned" << endl;
        // take 5? damage
    }
}
int main()
{
    //   -std=c++11
    srand(time(NULL)); // makes srand

    for (int i = 0; i < 10; i++)
    {
        int x = rand() % 2;
        cout << x << endl;
    }

    /*
    trainer *ai = new trainer("george");
    trainer *user = new trainer("george");
    Charmander *a = new Charmander(); // make a charmander
    //(*a).speak();                     // see name
    //(*a).stats();                     // see stats
    Bulbasaur *b = new Bulbasaur();
    //(*b).speak();
    (*user).r.add(a);
    (*ai).r.add(b);

    int currentPokemonAI = 0;
    int currentPokemonUser = 0;

    simulate_combat(ai, user, currentPokemonAI, currentPokemonUser, 2);
    // trainer attacking , trainer defending ,  place in array of pokemon in slot Attacking, Place in array ofPokemon in slot Defending, what move was chosen

    cout << "hp" << (*a).hp << endl;
    check_status(a);
    */
};

// 0 : normal
// 1 : fire
// 2: water
// 3: electric
// 4: grass
// 5: ice
// 6: fighting
// 7: poison
// 8: ground
// 9: flying
// 10: psychic
// 11: bug
// 12: rock
// 13: ghost
// 14 : dragon
// 15: dak