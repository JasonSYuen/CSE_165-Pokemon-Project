#include <iostream>
#include <string>
#include <vector>
#include "../updated_moves.h"

#pragma once

class M_submission : virtual public updated_moves
{
public:
    M_submission()
    {
        fill_values(80, "physical", "fighting", "recoil", 100, 100, "submission", "user takes 1/4 recoil damage");
    }

    container submission(int atk)
    {
        fill_values(80, "physical", "fighting", "recoil", 100, 100, "submission", "user takes 1/4 recoil damage");
        return activate(atk);
    }

    void image()
    {
    }
};