#include <iostream>
#include <string>
#include <vector>
#include "../updated_moves.h"

#pragma once

class M_scratch : virtual public updated_moves
{

public:
    M_scratch()
    {
        fill_values(40, "physical", "normal", "none", 100, 100, "scratch", "no additional effect");
    }

    container scratch(int atk)
    {
        // accuracy is 100 might need to make a random func later
        fill_values(40, "physical", "normal", "none", 100, 100, "scratch", "no additional effect");
        return activate(atk);
    }

    void image()
    {
    }
};