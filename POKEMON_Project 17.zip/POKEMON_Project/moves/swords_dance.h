#include <iostream>
#include <string>
#include <vector>
#include "../updated_moves.h"

#pragma once

class M_swords_dance : virtual public updated_moves
{
public:
    M_swords_dance()
    {
        fill_values(0, "non damaging", "normal", "double atk", 100, 100, "swords_dance", "doubles the users attack");
    }

    container swords_dance()
    {
        fill_values(0, "non damaging", "normal", "double atk", 100, 100, "swords_dance", "doubles the users attack");
        return activate();
    }

    void image()
    {
    }
};