#include <iostream>
#include <string>
#include <vector>
#include "../updated_moves.h"

#pragma once

class M_psychic : virtual public updated_moves
{
public:
    M_psychic()
    {
        fill_values(90, "special", "psychic", "lower enemy sp_def", 100, 33, "psychic", "has a 33 percent chance to lower enemy sp_def");
    }

    container psychic(int sp_atk)
    {
        fill_values(90, "special", "psychic", "lower enemy sp_def", 100, 33, "psychic", "has a 33 percent chance to lower enemy sp_def");
        return activate(sp_atk);
    }

    void image()
    {
    }
};