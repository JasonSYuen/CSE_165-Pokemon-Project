#include <iostream>
#include <string>
#include <vector>
#include "../updated_moves.h"

#pragma once

class M_stun_spore : virtual public updated_moves
{
public:
    M_stun_spore()
    {
        fill_values(0, "non damaging", "grass", "paralyze", 75, 100, "stun_spore", "75 percent chance to causes the target to become paralyzed");
    }

    container stun_spore()
    {
        fill_values(0, "non damaging", "grass", "paralyze", 75, 100, "stun_spore", "75 percent chance to causes the target to become paralyzed");
        return activate();
    }

    void image()
    {
    }
};