#include <iostream>
#include <string>
#include <vector>
#include "../updated_moves.h"

#pragma once

class M_peck : virtual public updated_moves
{
public:
    M_peck()
    {
        fill_values(35, "physical", "flying", "none", 100, 100, "peck", "no additional effect");
    }

    container peck(int atk)
    {
        fill_values(35, "physical", "flying", "none", 100, 100, "peck", "no additional effect");
        return activate(atk);
    }

    void image()
    {
    }
};