#include <iostream>
#include <string>
#include <vector>
#include "../updated_moves.h"

#pragma once

class M_agility : virtual public updated_moves
{
public:
    M_agility()
    {
        fill_values(0, "non damaging", "normal", "double speed", 100, 100, "agility", "double the users speed");
    }

    container agility()
    {
        fill_values(0, "non damaging", "normal", "double speed", 100, 100, "agility", "double the users speed");
        return activate();
    }

    void image()
    {
    }
};