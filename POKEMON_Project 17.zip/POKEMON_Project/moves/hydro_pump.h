#include <iostream>
#include <string>
#include <vector>
#include "../updated_moves.h"

#pragma once

class M_hydro_pump : virtual public updated_moves
{
public:
    M_hydro_pump()
    {
        fill_values(120, "special", "water", "none", 80, 100, "hydro_pump", "no additional effect");
    }

    container hydro_pump(int sp_atk)
    {
        fill_values(120, "special", "water", "none", 80, 100, "hydro_pump", "no additional effect");
        return activate(sp_atk);
    }

    void image()
    {
    }
};