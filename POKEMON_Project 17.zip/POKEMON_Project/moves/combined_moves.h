#include "agility.h"
#include "amnesia.h"
#include "blizzard.h"
#include "body_slam.h"
#include "double_edge.h"
#include "drill_peck.h"
#include "earthquake.h"
#include "explosion.h"
#include "fire_blast.h"
#include "flamethrower.h"
#include "hydro_pump.h"
#include "hyper_beam.h"
#include "hypnosis.h"
#include "peck.h"
#include "psychic.h"
#include "razor_leaf.h"
#include "recover.h"
#include "rock_slide.h"
#include "scratch.h"
#include "sing.h"
#include "slash.h"
#include "sleep_powder.h"
#include "sleep.h"
#include "spore.h"
#include "stun_spore.h"
#include "submission.h"
#include "surf.h"
#include "swords_dance.h"
#include "thunderbolt.h"
#include "thunder_wave.h"
#include "twineedle.h"

#pragma once

class everything : public M_agility, public M_amnesia, public M_blizzard, public M_body_slam, public M_double_edge, public M_drill_peck, public M_earthquake, public M_explosion, public M_fire_blast, public M_flamethrower, public M_hydro_pump, public M_hyper_beam, public M_hypnosis, public M_peck, public M_psychic, public M_razor_leaf, public M_recover, public M_rock_slide, public M_scratch, public M_sing, public M_slash, public M_sleep_powder, public M_sleep, public M_spore, public M_stun_spore, public M_submission, public M_surf, public M_swords_dance, public M_thunderbolt, public M_thunder_wave, public M_twineedle
{
public:
};