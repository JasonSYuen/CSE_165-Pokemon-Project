#include <iostream>
#include <string>
#include <vector>
#include "../updated_moves.h"

#pragma once

class M_sleep : virtual public updated_moves
{
public:
    M_sleep()
    {
        fill_values(0, "non damaging", "grass", "sleep", 100, 100, " sleep", "causes the target to fall asleep");
    }

    container sleep()
    {
        fill_values(0, "non damaging", "grass", "sleep", 100, 100, " sleep", "causes the target to fall asleep");
        return activate();
    }

    void image()
    {
    }
};