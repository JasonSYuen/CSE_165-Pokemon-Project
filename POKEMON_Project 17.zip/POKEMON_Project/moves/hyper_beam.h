#include <iostream>
#include <string>
#include <vector>
#include "../updated_moves.h"

#pragma once

class M_hyper_beam : virtual public updated_moves
{
public:
    M_hyper_beam()
    {
        fill_values(150, "physical", "normal", "skip next turn", 90, 100, "hyper_beam", "skip your next turn");
    }

    container hyper_beam(int atk)
    {
        fill_values(150, "physical", "normal", "skip next turn", 90, 100, "hyper_beam", "skip your next turn");
        return activate(atk);
    }

    void image()
    {
    }
};