#include <iostream>
#include <string>
#include <vector>
#include "../updated_moves.h"

#pragma once

class M_surf : virtual public updated_moves
{
public:
    M_surf()
    {
        fill_values(95, "special", "water", "none", 100, 100, "surf", "no additional effect");
    }

    container surf(int sp_atk)
    {
        fill_values(95, "special", "water", "none", 100, 100, "surf", "no additional effect");
        return activate(sp_atk);
    }

    void image()
    {
    }
};