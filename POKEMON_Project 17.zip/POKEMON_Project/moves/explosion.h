#include <iostream>
#include <string>
#include <vector>
#include "../updated_moves.h"

#pragma once

class M_explosion : virtual public updated_moves
{
public:
    M_explosion()
    {
        fill_values(170, "physical", "normal", "suicide", 100, 100, "explosion", "User pokemon faints");
    }

    container explosion(int atk)
    {
        fill_values(170, "physical", "normal", "suicide", 100, 100, "explosion", "User pokemon faints");
        return activate(atk);
    }

    void image()
    {
    }
};