#include <iostream>
#include <string>
#include <vector>
#include "../updated_moves.h"

#pragma once

class M_rock_slide : virtual public updated_moves
{
public:
    M_rock_slide()
    {
        fill_values(75, "physical", "rock", "none", 90, 100, "rock_slide", "no additional effect");
    }

    container rock_slide(int atk)
    {
        fill_values(75, "physical", "rock", "none", 90, 100, "rock_slide", "no additional effect");
        return activate(atk);
    }

    void image()
    {
    }
};