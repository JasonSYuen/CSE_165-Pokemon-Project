#include <iostream>
#include <string>
#include <vector>
#include "../updated_moves.h"

#pragma once

class M_slash : virtual public updated_moves
{
public:
    M_slash()
    {
        fill_values(70, "physical", "normal", "none", 100, 100, "slash", "no additional effect");
    }

    container slash(int atk)
    {
        fill_values(70, "physical", "normal", "none", 100, 100, "slash", "no additional effect");
        return activate(atk);
    }

    void image()
    {
    }
};