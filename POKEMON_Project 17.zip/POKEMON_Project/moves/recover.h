#include <iostream>
#include <string>
#include <vector>
#include "../updated_moves.h"

#pragma once

class M_recover : virtual public updated_moves
{
public:
    M_recover()
    {
        fill_values(0, "non damaging", "normal", "heal 50", 100, 100, " recover", "heal 1/2 max health");
    }

    container recover()
    {
        fill_values(0, "non damaging", "normal", "heal 50", 100, 100, " recover", "heal 1/2 max health");
        return activate();
    }

    void image()
    {
    }
};