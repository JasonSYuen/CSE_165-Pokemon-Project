#include <iostream>
#include <string>
#include <vector>
#include "../updated_moves.h"

#pragma once

class M_fire_blast : virtual public updated_moves
{
public:
    M_fire_blast()
    {
        fill_values(120, "special", "fire", "burn", 85, 30, "fire_blast", "has a 30 percent chance to burn the target");
    }

    container fire_blast(int sp_atk)
    {
        fill_values(120, "special", "fire", "burn", 85, 30, "fire_blast", "has a 30 percent chance to burn the target");
        return activate(sp_atk);
    }

    void image()
    {
    }
};