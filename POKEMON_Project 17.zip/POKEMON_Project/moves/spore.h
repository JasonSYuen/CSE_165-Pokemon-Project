#include <iostream>
#include <string>
#include <vector>
#include "../updated_moves.h"

#pragma once

class M_spore : virtual public updated_moves
{
public:
    M_spore()
    {
        fill_values(0, "non damaging", "grass", "sleep", 100, 100, "spore", "causes the target to fall asleep");
    }

    container spore()
    {
        fill_values(0, "non damaging", "grass", "sleep", 100, 100, "spore", "causes the target to fall asleep");
        return activate();
    }

    void image()
    {
    }
};