#include <iostream>
#include <string>
#include <vector>
#include "../updated_moves.h"

#pragma once

class M_twineedle : virtual public updated_moves
{
public:
    M_twineedle()
    {
        fill_values(25, "physical", "bug", "poison", 100, 20, "twineedle", "has a 20 percent chance to poison the target");
    }

    container twineedle(int sp_atk)
    {
        fill_values(25, "physical", "bug", "poison", 100, 20, "twineedle", "has a 20 percent chance to poison the target");
        return activate(sp_atk);
    }

    void image()
    {
    }
};