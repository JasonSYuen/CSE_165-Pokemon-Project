#include <iostream>
#include <string>
#include <vector>
using namespace std;

#pragma once;
class type_matchup_sheet
{
public:
    double arr[16][16] = {
        {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0.5, 0, 1, 1},
        {1, 0.5, 0.5, 1, 2, 2, 1, 1, 1, 1, 1, 2, 0.5, 1, 0.5, 1},
        {1, 2, 0.5, 1, 0.5, 1, 1, 1, 2, 1, 1, 1, 2, 1, 0.5, 1},
        {1, 1, 2, 0.5, 0.5, 1, 1, 1, 0, 2, 1, 1, 1, 1, 0.5, 1},
        {1, 0.5, 2, 1, 0.5, 1, 1, 0.5, 2, 0.5, 1, 0.5, 2, 1, 0.5, 1},
        {1, 0.5, 0.5, 1, 2, 0.5, 1, 1, 2, 2, 1, 1, 1, 1, 2, 1},
        {2, 1, 1, 1, 1, 2, 1, 0.5, 1, 0.5, 0.5, 0.5, 2, 0, 1, 2},
        {1, 1, 1, 1, 2, 1, 1, 0.5, 0.5, 1, 1, 1, 0.5, 0.5, 1, 1},
        {1, 2, 1, 2, 0.5, 1, 1, 2, 1, 0, 1, 0.5, 2, 1, 1, 1},
        {1, 1, 1, 0.5, 2, 1, 2, 1, 1, 1, 1, 2, 0.5, 1, 1, 1},
        {1, 1, 1, 1, 1, 1, 2, 2, 1, 1, 0.5, 1, 1, 1, 1, 0},
        {1, 0.5, 1, 1, 2, 1, 0.5, 0.5, 1, 0.5, 2, 1, 1, 1, 1, 2},
        {1, 2, 1, 1, 1, 2, 0.5, 1, 0.5, 2, 1, 2, 1, 1, 1, 1},
        {0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 0.5},
        {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0.5, 1},
        {1, 1, 1, 1, 1, 1, 0.5, 1, 1, 1, 2, 1, 1, 1, 1, 0.5}

    };

    int type_to_num(string a)
    {
        if (a == "normal")
        {
            return 0;
        }
        if (a == "fire")
        {
            return 1;
        }
        if (a == "water")
        {
            return 2;
        }
        if (a == "electric")
        {
            return 3;
        }
        if (a == "grass")
        {
            return 4;
        }
        if (a == "ice")
        {
            return 5;
        }
        if (a == "fighting")
        {
            return 6;
        }

        if (a == "poison")
        {
            return 7;
        }
        if (a == "ground")
        {
            return 8;
        }
        if (a == "flying")
        {
            return 9;
        }
        if (a == "psychic")
        {
            return 10;
        }
        if (a == "bug")
        {
            return 11;
        }
        if (a == "rock")
        {
            return 12;
        }
        if (a == "ghost")
        {
            return 13;
        }
        if (a == "dragon")
        {
            return 14;
        }
        if (a == "dark")
        {
            return 15;
        }
    }
    float fix_type(string atk, string def1, string def2)
    {
        float x = 1;
        int atk_num = type_to_num(atk);
        int def1_num = type_to_num(def1);
        int def2_num = type_to_num(def2);

        x = x * arr[atk_num][def1_num] * arr[atk_num][def2_num];
        return x;
    }

    float fix_type(string atk, string def1)
    {
        float x = 1;
        int atk_num = type_to_num(atk);
        int def1_num = type_to_num(def1);

        x = x * arr[atk_num][def1_num];
        return x;
    }
};

// 0 : normal
// 1 : fire
// 2: water
// 3: electric
// 4: grass
// 5: ice
// 6: fighting
// 7: poison
// 8: ground
// 9: flying
// 11: psychic
// 11: bug
// 12: rock
// 13: ghost
// 14 : dragon
// 15: dak
