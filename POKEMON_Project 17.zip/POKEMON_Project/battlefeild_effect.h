#include <iostream>
#include <string>
#include <vector>
using namespace std;

#pragma once
class battlefeild_effect
{
public:
    int timer;
    // bool location    (your side or opponent side)

    battlefeild_effect()
    {
    }
    void display(bool location)
    {
        // location =  your side or opponent side
    }
};