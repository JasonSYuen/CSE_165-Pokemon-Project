#include <iostream>
#include <string>
#include <vector>
#include "../updated_moves.h"

#pragma once

class M_razor_leaf : virtual public updated_moves
{
public:
    M_razor_leaf()
    {
        fill_values(55, "special", "grass", "none", 95, 100, "razor leaf", "no additional effect");
    }

    container razor_leaf(int sp_atk)
    {
        fill_values(55, "special", "grass", "none", 95, 100, "razor leaf", "no additional effect");
        return activate(sp_atk);
    }

    void image()
    {
    }
};