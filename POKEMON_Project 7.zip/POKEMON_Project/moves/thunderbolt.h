#include <iostream>
#include <string>
#include <vector>
#include "../updated_moves.h"

#pragma once

class M_thunderbolt : virtual public updated_moves
{
public:
    M_thunderbolt()
    {
        fill_values(95, "special", "electric", "paralyze", 100, 10, "thunderbolt", "has a 10 percent chance to paralyze the target");
    }

    container thunderbolt(int sp_atk)
    {
        fill_values(95, "special", "electric", "paralyze", 100, 10, "thunderbolt", "has a 10 percent chance to paralyze the target");
        return activate(sp_atk);
    }

    void image()
    {
    }
};