#include <iostream>
#include <string>
#include <vector>
#include "../updated_moves.h"

#pragma once

class M_thunder_wave : virtual public updated_moves
{
public:
    M_thunder_wave()
    {
        fill_values(0, "non damaging", "electric", "paralyze", 100, 100, "thunder_wave", "causes the target to become paralyzed");
    }

    container thunder_wave()
    {
        fill_values(0, "non damaging", "electric", "paralyze", 100, 100, "thunder_wave", "causes the target to become paralyzed");
        return activate();
    }

    void image()
    {
    }
};