#include <iostream>
#include <string>
#include <vector>
#include "../updated_moves.h"

#pragma once

class M_body_slam : virtual public updated_moves
{
public:
    M_body_slam()
    {
        fill_values(85, "physical", "normal", "paralyze", 100, 30, "body_slam", "has a 30 percent chance to paralyze the target");
    }

    container body_slam(int atk)
    {
        fill_values(85, "physical", "normal", "paralyze", 100, 30, "body_slam", "has a 30 percent chance to paralyze the target");
        return activate(atk);
    }

    void image()
    {
    }
};