#include <iostream>
#include <string>
#include <vector>
#include "../updated_moves.h"

#pragma once

class M_drill_peck : virtual public updated_moves
{
public:
    M_drill_peck()
    {
        fill_values(80, "physical", "flying", "none", 100, 100, "drill_peck", "no additional effect");
    }

    container drill_peck(int atk)
    {
        fill_values(80, "physical", "flying", "none", 100, 100, "drill_peck", "no additional effect");
        return activate(atk);
    }

    void image()
    {
    }
};