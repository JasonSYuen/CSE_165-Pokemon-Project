#include <iostream>
#include <string>
#include <vector>
#include "../updated_moves.h"

#pragma once

class M_double_edge : virtual public updated_moves
{
public:
    M_double_edge()
    {
        fill_values(100, "physical", "normal", "recoil", 100, 100, "double_edge", "user takes 1/4 recoil damage");
    }

    container double_edge(int atk)
    {
        fill_values(100, "physical", "normal", "recoil", 100, 100, "double_edge", "user takes 1/4 recoil damage");
        return activate(atk);
    }

    void image()
    {
    }
};