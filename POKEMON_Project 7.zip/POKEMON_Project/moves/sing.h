#include <iostream>
#include <string>
#include <vector>
#include "../updated_moves.h"

#pragma once

class M_sing : virtual public updated_moves
{
public:
    M_sing()
    {
        fill_values(0, "non damaging", "normal", "sleep", 55, 100, "sing", "55 percent chance to causes the target to fall asleep");
    }

    container sing()
    {
        fill_values(0, "non damaging", "normal", "sleep", 55, 100, "sing", "55 percent chance to causes the target to fall asleep");
        return activate();
    }

    void image()
    {
    }
};