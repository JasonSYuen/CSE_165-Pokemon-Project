#include <iostream>
#include <string>
#include <vector>
#include "../updated_moves.h"

#pragma once

class M_earthquake : virtual public updated_moves
{
public:
    M_earthquake()
    {
        fill_values(100, "physical", "ground", "none", 100, 100, "earthquake", "no additional effect");
    }

    container earthquake(int atk)
    {
        fill_values(100, "physical", "ground", "none", 100, 100, "earthquake", "no additional effect");
        return activate(atk);
    }

    void image()
    {
    }
};