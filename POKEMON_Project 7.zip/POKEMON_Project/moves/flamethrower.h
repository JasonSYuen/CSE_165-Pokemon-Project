#include <iostream>
#include <string>
#include <vector>
#include "../updated_moves.h"

#pragma once

class M_flamethrower : virtual public updated_moves
{
public:
    M_flamethrower()
    {
        // cout << "a" << endl;
        fill_values(95, "special", "fire", "burn", 100, 10, "flamethrower", "has a 10 percent chance to burn the target");
    }

    container flamethrower(int sp_atk)
    {
        fill_values(95, "special", "fire", "burn", 100, 10, "flamethrower", "has a 10 percent chance to burn the target");
        return activate(sp_atk);
    }

    void image()
    {
    }
};