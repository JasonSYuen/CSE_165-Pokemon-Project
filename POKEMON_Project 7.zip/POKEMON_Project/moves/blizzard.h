#include <iostream>
#include <string>
#include <vector>
#include "../updated_moves.h"

#pragma once

class M_blizzard : virtual public updated_moves
{
public:
    M_blizzard()
    {
        fill_values(120, "special", "ice", "freeze", 90, 10, "blizzard", "has a 10 percent chance to freeze the target");
    }

    container blizzard(int atk)
    {
        fill_values(120, "special", "ice", "freeze", 90, 10, "blizzard", "has a 10 percent chance to freeze the target");
        return activate(atk);
    }

    void image()
    {
    }
};