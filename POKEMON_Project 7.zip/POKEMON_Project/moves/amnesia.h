#include <iostream>
#include <string>
#include <vector>
#include "../updated_moves.h"

#pragma once

class M_amnesia : virtual public updated_moves
{
public:
    M_amnesia()
    {
        fill_values(0, "non damaging", "psychic", "double sp_atk", 100, 100, " amnesia", "double user sp_atk");
    }

    container amnesia()
    {
        fill_values(0, "non damaging", "psychic", "double sp_atk", 100, 100, " amnesia", "double user sp_atk");
        return activate();
    }

    void image()
    {
    }
};