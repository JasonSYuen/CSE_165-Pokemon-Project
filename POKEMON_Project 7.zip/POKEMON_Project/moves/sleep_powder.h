#include <iostream>
#include <string>
#include <vector>
#include "../updated_moves.h"

#pragma once

class M_sleep_powder : virtual public updated_moves
{
public:
    M_sleep_powder()
    {
        fill_values(0, "non damaging", "grass", "sleep", 100, 100, "sleep_powder", "75 percent chance to causes the target to fall asleep");
    }

    container sleep_powder()
    {
        fill_values(0, "non damaging", "grass", "sleep", 100, 100, "sleep_powder", "75 percent chance to causes the target to fall asleep");
        return activate();
    }

    void image()
    {
    }
};