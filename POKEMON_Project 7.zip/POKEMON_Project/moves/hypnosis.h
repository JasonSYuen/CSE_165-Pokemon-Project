#include <iostream>
#include <string>
#include <vector>
#include "../updated_moves.h"

#pragma once

class M_hypnosis : virtual public updated_moves
{
public:
    M_hypnosis()
    {
        fill_values(0, "non damaging", "psychic", "sleep", 60, 100, "hypnosis", "60 percent chance to causes the target to fall asleep");
    }

    container hypnosis()
    {
        fill_values(0, "non damaging", "psychic", "sleep", 60, 100, "hypnosis", "60 percent chance to causes the target to fall asleep");
        return activate();
    }

    void image()
    {
    }
};