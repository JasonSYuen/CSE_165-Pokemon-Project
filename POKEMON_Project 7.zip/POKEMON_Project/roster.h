#include <iostream>
using namespace std;
#include <vector>
#include <typeinfo>
#include "BasePokemon.h"
#pragma once
class Roster
{
public:
    vector<Pokemon *> listOfPokemon;

    Roster()
    {
    }

    void add(Pokemon *p)
    {
        listOfPokemon.push_back(p);
    }

    void print()
    {
        for (int i = 0; i < listOfPokemon.size(); i++)
        {
            listOfPokemon[i]->speak();
        }
    }

    Pokemon *view(int place_in_vector)
    {
        return (listOfPokemon[place_in_vector]);
    }
};