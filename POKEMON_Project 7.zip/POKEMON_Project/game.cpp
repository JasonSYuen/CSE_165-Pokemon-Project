
#include <iostream>
#include "IncludeEverything.h"
#include "Roster.h"
#include "trainer.h"
#include <vector>
#pragma once
using namespace std;

int main()
{
    srand(time(NULL)); // makes srand

    Charmander *a = new Charmander(); // make a charmander
    Bulbasaur *b = new Bulbasaur();

    trainer *user = new trainer("USER"); // make trainer   (trainers are pretty much just rosters)
    (*user).r.add(a);                    // add pokemon to trainer roster

    trainer *ai = new trainer("AI");
    (*ai).r.add(b); // add pokemon to trainer roster

    int gameEnd = 0;
    int currentPokemonUser = 0; // index of the active pokemon in the roster of user
    int currentPokemonAI = 0;   // index of the active pokemon in the roster of AI
    int userChoice = 0;         // what the user wants to do
    int validChoice = 0;        // verifies user input
    int selectedMove = 0;
    int selectedMoveAI = 1;

    cout << (*ai).name << " sends out ";
    (*ai).r.view(currentPokemonAI);
    cout << endl;

    cout << (*user).name << " sends out ";
    (*user).r.view(currentPokemonUser);
    cout << endl;

    while (gameEnd != 1)
    { // game will only end when this value is set to 1

        cout << "What would you like to do?" << endl;
        cout << "1. Attack" << endl;
        cout << "2. Switch Pokemon" << endl;
        cin >> userChoice;

        while (validChoice != 1)
        {
            validChoice = 1;
            if (userChoice == 1)
            {
                // cout << (((*user).r.view(0)))->move1().total_attack_damage << endl;
                // cout << (((*user).r.view(0)))->desc();
                (((*user).r.view(currentPokemonUser)->print_moves()));
                cout << "Which move would you like to use?" << endl;
                cout << "Move ";
                cin >> selectedMove;
                // select chosen attack
            }
            else if (userChoice == 2)
            { // switch pokemon option
                cin >> currentPokemonUser;
                cout << (*user).name << " sends out ";
                (*user).r.view(currentPokemonUser);
                cout << endl;
            }
            else
            {
                validChoice = 0;
                cin >> userChoice;
            }
        }
        validChoice = 0;

        if (userChoice == 1)
        {
            int damageDealt = (((*user).r.view(currentPokemonUser)))->move1().total_attack_damage;
            if ((((*user).r.view(currentPokemonUser)->speed)) > (((*ai).r.view(currentPokemonAI)->speed)))
            { // check speed

                // user's pokemon is faster
                cout << (*user).name << "'s " << (*user).r.view(currentPokemonUser)->name << " uses "
                     << "INSERT MOVE NAME" << endl;
                if (selectedMove == 1)
                { // turn this into a function later, crude programming rn mb, the defenses, typing, etc aren't implemented properly, no damage message
                    (((*ai).r.view(currentPokemonAI)->hp)) = (((*ai).r.view(currentPokemonAI)->hp)) - ((((*user).r.view(currentPokemonUser)))->move1().total_attack_damage / (10 * (((*ai).r.view(currentPokemonAI)->def))));
                }
                else if (selectedMove == 2)
                {
                    (((*ai).r.view(currentPokemonAI)->hp)) = (((*ai).r.view(currentPokemonAI)->hp)) - ((((*user).r.view(currentPokemonUser)))->move2().total_attack_damage / (10 * (((*ai).r.view(currentPokemonAI)->def))));
                }
                else if (selectedMove == 3)
                {
                    (((*ai).r.view(currentPokemonAI)->hp)) = (((*ai).r.view(currentPokemonAI)->hp)) - ((((*user).r.view(currentPokemonUser)))->move3().total_attack_damage / (10 * (((*ai).r.view(currentPokemonAI)->def))));
                }
                else if (selectedMove == 4)
                {
                    (((*ai).r.view(currentPokemonAI)->hp)) = (((*ai).r.view(currentPokemonAI)->hp)) - ((((*user).r.view(currentPokemonUser)))->move4().total_attack_damage / (10 * (((*ai).r.view(currentPokemonAI)->def))));
                }
                // calculate damage dealt
                // deal damage

                if ((*ai).r.view(currentPokemonAI)->hp <= 0)
                {
                    // AI pokemon has fainted, no attack goes through
                    // delete AI pokemon and give a death message
                }
                else
                { // ai attacks
                    cout << (*user).name << "'s " << (*user).r.view(currentPokemonUser)->name << " uses "
                         << "INSERT MOVE NAME" << endl;
                    if (selectedMove == 1)
                    { // turn this into a function later, crude programming rn mb, the defenses, typing, etc aren't implemented properly, no damage message
                        (((*user).r.view(currentPokemonUser)->hp)) = (((*user).r.view(currentPokemonUser)->hp)) - ((((*ai).r.view(currentPokemonAI)))->move1().total_attack_damage / (10 * (((*user).r.view(currentPokemonUser)->def))));
                    }
                    else if (selectedMove == 2)
                    {
                        (((*user).r.view(currentPokemonUser)->hp)) = (((*user).r.view(currentPokemonUser)->hp)) - ((((*ai).r.view(currentPokemonAI)))->move2().total_attack_damage / (10 * (((*user).r.view(currentPokemonUser)->def))));
                    }
                    else if (selectedMove == 3)
                    {
                        (((*user).r.view(currentPokemonUser)->hp)) = (((*user).r.view(currentPokemonUser)->hp)) - ((((*ai).r.view(currentPokemonAI)))->move3().total_attack_damage / (10 * (((*user).r.view(currentPokemonUser)->def))));
                    }
                    else if (selectedMove == 4)
                    {
                        (((*user).r.view(currentPokemonUser)->hp)) = (((*user).r.view(currentPokemonUser)->hp)) - ((((*ai).r.view(currentPokemonAI)))->move4().total_attack_damage / (10 * (((*user).r.view(currentPokemonUser)->def))));
                    }
                }
                if ((*user).r.view(currentPokemonUser)->hp <= 0)
                {
                    // AI pokemon has fainted
                    // delete AI pokemon and give a death message
                }
                // check for faint
                // if fainted, delete pokemon
                // if not fainted, deal return damage
                // check for faint
                // if fainted, delete pokemon
            }
        }

        // - implement enemy attack choice
        // - calculate the damage dealt to the slower pokemon
        // - if the slower pokemon lives, deal the damage to the faster pokemon
        // - if the slower pokemon faints, check if there are any remaining pokemon (FOR NOW FAINTING MEANS DELETING THE POKEMON FROM THE ROSTER)
        // - if there are remaining pokemon, give the user the option to choose from them

        if ((*ai).r.listOfPokemon.size() == 0)
        {
            gameEnd = 1;
        }
        else if ((*user).r.listOfPokemon.size() == 0)
        {
            gameEnd = 1;
        }
    }
};

// int main()
// {

//     srand(time(NULL)); // makes srand

//     Charmander *a = new Charmander(); // make a charmander
//     (*a).speak();                     // see name
//     (*a).stats();                     // see stats
//     Bulbasaur *b = new Bulbasaur();
//     (*b).speak();
//     (*b).stats();

//     Roster *list = new Roster(); // make roster

//     (*list).add(a); // add to roster
//     (*list).add(b);
//     (*list).print(); // print out roster

//     cout << (*a).move1().total_attack_damage << endl; // look at move damage (atk * pp)
//     cout << (*a).move1().damagetype << endl;          // look at damage type (grass, water, etc)
//     cout << (*a).move1().special_or_not << endl;      // what type of damage (special/not)

//     Vileplume *v = new Vileplume();
//     (*list).add(v);

//     (*list).print();

//     trainer *user = new trainer("george"); // make trainer   (trainers are pretty much just rosters)

//     (*user).r.add(a); // add pokemon to trainer roster

//     Pokemon *asadd = (((*user).r.view(0)));
//     Charmander *tre = dynamic_cast<Charmander *>(asadd);
//     cout << (*tre).move1().total_attack_damage << endl;

//     cout << (((*user).r.view(0)))->move1().total_attack_damage << endl;
//     // asadd.speak();
//     // cout << *(((*user).r.view(0))).move1().total_attack_damage;

//     //(*user).(r.view(0)).move1(); // print trainer roster

//     // cout << (*user).(r.view(0)).move1().total_attack_damage << endl;
//     //(*user).(r)

//     //.move1().total_attack_damage

//     /*
//     for (int i = 0; i < 10; i++)
//     {
//         cout << (*b).move2().status << endl; // checks to see if status goes off
//     }

//     Dragonite *dragonite = new Dragonite();

//     Moltres *moltres = new Moltres();

//     auto x = (*dragonite).move1();

//     Articuno *birb = new Articuno();

//     (*birb).print_moves();

//     updated_moves *scratch = new M_scratch();

//     cout << (*scratch).damagetype << endl;

//     updated_moves *sleep = new M_sleep();

//     cout << (*sleep).damagetype << endl;

//     cout << (*scratch).damagetype << endl;

//     vector<string> s = (*scratch).desc();

//     for (string i : s)
//     {
//         cout << i << endl;
//     }

//     s = (*sleep).desc();

//     for (string i : s)
//     {
//         cout << i << endl;
//     }

//     cout << (*sleep).sleep().status << endl;
//     */
// };
