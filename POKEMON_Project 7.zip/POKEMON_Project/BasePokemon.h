#include <iostream>
#include <string>
#include <vector>
#include "moves/combined_moves.h"
using namespace std;

#pragma once
class Pokemon : public everything
{
public:
    vector<string> type;
    string name;
    int hp;
    int atk;
    int def;
    int sp_atk;
    int sp_def;
    int speed;

    string status;

    string MyMove1_name;
    string MyMove2_name;
    string MyMove3_name;
    string MyMove4_name;

    virtual container move1() = 0;
    virtual container move2() = 0;
    virtual container move3() = 0;
    virtual container move4() = 0;

    virtual void speak()
    {
        cout << "aAA " << endl;
    }

    void stats()
    {
        cout << "hp: " << hp << endl;
        cout << "atk: " << atk << endl;
        cout << "def: " << def << endl;
        cout << "sp_atk: " << sp_atk << endl;
        cout << "sp_def: " << sp_def << endl;
        cout << "speed: " << speed << endl;
        for (string i : type)
        {
            cout << i << endl;
        }
    }

    virtual void print_moves()
    {
        cout << "move1" << endl;
        cout << "move2" << endl;
        cout << "move3" << endl;
        cout << "move4" << endl;
    }

    vector<string> get_move1()
    {
        return move_description(this->MyMove1_name);
    }
    vector<string> get_move2()
    {
        return move_description(this->MyMove2_name);
    }
    vector<string> get_move3()
    {
        return move_description(this->MyMove3_name);
    }
    vector<string> get_move4()
    {
        return move_description(this->MyMove4_name);
    }

    vector<string> move_description(string x)
    {
        if (x == "agility")
        {
            updated_moves *move_obj = new M_agility();
            vector<string> descriptors = (*move_obj).desc();
            return descriptors;
        }
        if (x == "amnesia")
        {
            updated_moves *move_obj = new M_amnesia();
            vector<string> descriptors = (*move_obj).desc();
            return descriptors;
        }
        if (x == "blizzard")
        {
            updated_moves *move_obj = new M_blizzard();
            vector<string> descriptors = (*move_obj).desc();
            return descriptors;
        }
        if (x == "blizzard")
        {
            updated_moves *move_obj = new M_blizzard();
            vector<string> descriptors = (*move_obj).desc();
            return descriptors;
        }

        if (x == "body_slam")
        {
            updated_moves *move_obj = new M_body_slam();
            vector<string> descriptors = (*move_obj).desc();
            return descriptors;
        }

        if (x == "double_edge")
        {
            updated_moves *move_obj = new M_double_edge();
            vector<string> descriptors = (*move_obj).desc();
            return descriptors;
        }

        if (x == "drill_peck")
        {
            updated_moves *move_obj = new M_drill_peck();
            vector<string> descriptors = (*move_obj).desc();
            return descriptors;
        }

        if (x == "earthquake")
        {
            updated_moves *move_obj = new M_earthquake();
            vector<string> descriptors = (*move_obj).desc();
            return descriptors;
        }

        if (x == "explosion")
        {
            updated_moves *move_obj = new M_explosion();
            vector<string> descriptors = (*move_obj).desc();
            return descriptors;
        }

        if (x == "fire_blast")
        {
            updated_moves *move_obj = new M_fire_blast();
            vector<string> descriptors = (*move_obj).desc();
            return descriptors;
        }
        if (x == "flamethrower")
        {
            updated_moves *move_obj = new M_flamethrower();
            vector<string> descriptors = (*move_obj).desc();
            return descriptors;
        }
        if (x == "hydro_pump")
        {
            updated_moves *move_obj = new M_hydro_pump();
            vector<string> descriptors = (*move_obj).desc();
            return descriptors;
        }
        if (x == "hypnosis")
        {
            updated_moves *move_obj = new M_hypnosis();
            vector<string> descriptors = (*move_obj).desc();
            return descriptors;
        }
        if (x == "peck")
        {
            updated_moves *move_obj = new M_peck();
            vector<string> descriptors = (*move_obj).desc();
            return descriptors;
        }
        if (x == "psychic")
        {
            updated_moves *move_obj = new M_psychic();
            vector<string> descriptors = (*move_obj).desc();
            return descriptors;
        }
        if (x == "razor_leaf")
        {
            updated_moves *move_obj = new M_razor_leaf();
            vector<string> descriptors = (*move_obj).desc();
            return descriptors;
        }
        if (x == "recover")
        {
            updated_moves *move_obj = new M_recover();
            vector<string> descriptors = (*move_obj).desc();
            return descriptors;
        }

        if (x == "rock_slide")
        {
            updated_moves *move_obj = new M_rock_slide();
            vector<string> descriptors = (*move_obj).desc();
            return descriptors;
        }

        if (x == "scratch")
        {
            updated_moves *move_obj = new M_scratch();
            vector<string> descriptors = (*move_obj).desc();
            return descriptors;
        }

        if (x == "sing")
        {
            updated_moves *move_obj = new M_sing();
            vector<string> descriptors = (*move_obj).desc();
            return descriptors;
        }

        if (x == "slash")
        {
            updated_moves *move_obj = new M_slash();
            vector<string> descriptors = (*move_obj).desc();
            return descriptors;
        }

        if (x == "sleep_powder")
        {
            updated_moves *move_obj = new M_sleep_powder();
            vector<string> descriptors = (*move_obj).desc();
            return descriptors;
        }

        if (x == "sleep")
        {
            updated_moves *move_obj = new M_sleep();
            vector<string> descriptors = (*move_obj).desc();
            return descriptors;
        }

        if (x == "spore")
        {
            updated_moves *move_obj = new M_spore();
            vector<string> descriptors = (*move_obj).desc();
            return descriptors;
        }

        if (x == "stun_spore")
        {
            updated_moves *move_obj = new M_stun_spore();
            vector<string> descriptors = (*move_obj).desc();
            return descriptors;
        }

        if (x == "submission")
        {
            updated_moves *move_obj = new M_submission();
            vector<string> descriptors = (*move_obj).desc();
            return descriptors;
        }
        if (x == "surf")
        {
            updated_moves *move_obj = new M_surf();
            vector<string> descriptors = (*move_obj).desc();
            return descriptors;
        }
        if (x == "swords_dance")
        {
            updated_moves *move_obj = new M_swords_dance();
            vector<string> descriptors = (*move_obj).desc();
            return descriptors;
        }
        if (x == "thunder_wave")
        {
            updated_moves *move_obj = new M_thunder_wave();
            vector<string> descriptors = (*move_obj).desc();
            return descriptors;
        }

        if (x == "thunderbolt")
        {
            updated_moves *move_obj = new M_thunderbolt();
            vector<string> descriptors = (*move_obj).desc();
            return descriptors;
        }
        if (x == "twineedle")
        {
            updated_moves *move_obj = new M_twineedle();
            vector<string> descriptors = (*move_obj).desc();
            return descriptors;
        }
    }
};