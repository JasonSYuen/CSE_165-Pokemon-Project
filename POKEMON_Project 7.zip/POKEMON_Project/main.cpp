
#include <iostream>
#include "IncludeEverything.h"
#include "trainer.h"
#include <vector>
#include "moves/combined_moves.h"
using namespace std;

int main()
{
    //   -std=c++11
    srand(time(NULL)); // makes srand

    Charmander *a = new Charmander(); // make a charmander
    (*a).speak();                     // see name
    //(*a).stats();                     // see stats
    Bulbasaur *b = new Bulbasaur();
    (*b).speak();
    //(*b).stats();

    trainer *user = new trainer("george");
    (*user).r.add(a);
    cout << (((*user).r.view(0)))->move1().total_attack_damage << endl; // user pokemon 1 use move 1 get total damage

    updated_moves *flamethrower_1 = new M_flamethrower();

    // cout << ((*flamethrower_1).desc())[] << endl;

    for (int i = 0; i < ((*flamethrower_1).desc()).size(); i++)
    {
        cout << ((*flamethrower_1).desc())[i] << endl; // getting descir
    }
    cout << endl;

    for (int i = 0; i < ((a->get_move1())).size(); i++)
    {
        cout << ((a->get_move1()))[i] << endl; // getting descir
    }

    /*
Roster *list = new Roster(); // make roster

(*list).add(a); // add to roster
(*list).add(b);
(*list).print(); // print out roster

cout << (*a).move1().total_attack_damage << endl; // look at move damage (atk * pp)
cout << (*a).move1().damagetype << endl;          // look at damage type (grass, water, etc)
cout << (*a).move1().special_or_not << endl;      // what type of damage (special/not)
cout << (*a).move1().status << endl;
cout << endl;

cout << (*a).move2().total_attack_damage << endl; // look at move damage (atk * pp)
cout << (*a).move2().damagetype << endl;          // look at damage type (grass, water, etc)
cout << (*a).move2().special_or_not << endl;

Vileplume *v = new Vileplume();
(*list).add(v);

(*list).print();

trainer *user = new trainer("george"); // make trainer   (trainers are pretty much just rosters)

(*user).r.add(a); // add pokemon to trainer roster

Pokemon *asadd = (((*user).r.view(0)));
Charmander *tre = dynamic_cast<Charmander *>(asadd);
cout << (*tre).move1().total_attack_damage << endl;

cout << (((*user).r.view(0)))->move1().total_attack_damage << endl;
*/
    // asadd.speak();
    // cout << *(((*user).r.view(0))).move1().total_attack_damage;

    //(*user).(r.view(0)).move1(); // print trainer roster

    // cout << (*user).(r.view(0)).move1().total_attack_damage << endl;
    //(*user).(r)

    //.move1().total_attack_damage

    /*
    for (int i = 0; i < 10; i++)
    {
        cout << (*b).move2().status << endl; // checks to see if status goes off
    }

    Dragonite *dragonite = new Dragonite();

    Moltres *moltres = new Moltres();

    auto x = (*dragonite).move1();

    Articuno *birb = new Articuno();

    (*birb).print_moves();
    */
    /*
    updated_moves *scratch = new M_scratch();

    cout << (*scratch).damagetype << endl;

    updated_moves *sleep = new M_sleep();

    cout << (*sleep).damagetype << endl;

    cout << (*scratch).damagetype << endl;

    vector<string> s = (*scratch).desc();

    for (string i : s)
    {
        cout << i << endl;
    }

    s = (*sleep).desc();

    for (string i : s)
    {
        cout << i << endl;
    }
    */
    // cout << (sleep)->sleep().status << endl;
};
