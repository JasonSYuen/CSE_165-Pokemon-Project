#include <iostream>
#include <string>
#include <vector>
#include "../BasePokemon.h"
#pragma once

using namespace std;

class Omastar : public Pokemon
{

public:
    Omastar()
    {
        (this->type).push_back("rock");
        (this->type).push_back("water");
        this->name = "Omastar";
        this->hp = 70;
        this->atk = 60;
        this->def = 125;
        this->sp_atk = 115;
        this->sp_def = 70;
        this->speed = 55;

        this->MyMove1_name = "blizzard";
        this->MyMove2_name = "hydro_pump";
        this->MyMove3_name = "body_slam";
        this->MyMove3_name = "recover";
    };

    void speak() override
    {
        cout << name << endl;
    }

    container move1() override
    {
        return blizzard(sp_atk);
    }
    container move2() override
    {
        return hydro_pump(sp_atk);
    }
    container move3() override
    {
        return body_slam(atk);
    }
    container move4() override
    {
        return recover();
    }
    void print_moves() override
    {
        cout << "blizzard\n"
             << "hydro_pump\n"
             << "body_slam\n"
             << "recover\n";
    }
};
