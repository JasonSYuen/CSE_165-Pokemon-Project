#include <iostream>
#include <string>
#include <vector>
#include "../BasePokemon.h"

#pragma once

using namespace std;

class Charmander : public Pokemon
{
    // string name = "Charmander";

public:
    Charmander()
    {
        (this->type).push_back("fire");
        this->name = "Charmander";
        this->hp = 39;
        this->atk = 52;
        this->def = 43;
        this->sp_atk = 60;
        this->sp_def = 50;
        this->speed = 65;

        this->MyMove1_name = "flamethrower";
        this->MyMove2_name = "fire_blast";
        this->MyMove3_name = "slash";
        this->MyMove3_name = "submission";
    };

    void speak() override
    {
        cout << name << endl;
    }

    container move1() override
    {
        // updated_moves *x = new M_flamethrower();
        return flamethrower(sp_atk);
    }
    container move2() override
    {
        return fire_blast(sp_atk);
    }
    container move3() override
    {
        return slash(atk);
    }
    container move4() override
    {
        return submission(atk);
    }

    void print_moves() override
    {
        cout << "flamethrower\n"
             << "fire blast\n"
             << "slash\n"
             << "submission\n";
    }
};
