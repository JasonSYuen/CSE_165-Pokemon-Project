#include <iostream>
#include <string>
#include <vector>
#include "../BasePokemon.h"
#pragma once

using namespace std;

class Mewtwo : public Pokemon
{

public:
    Mewtwo()
    {
        (this->type).push_back("psychic");
        this->name = "Mewtwo";
        this->hp = 106;
        this->atk = 110;
        this->def = 90;
        this->sp_atk = 154;
        this->sp_def = 90;
        this->speed = 130;

        this->MyMove1_name = "submission";
        this->MyMove2_name = "earthquake";
        this->MyMove3_name = "body_slam";
        this->MyMove3_name = "hyper_beam";
    };

    void speak() override
    {
        cout << name << endl;
    }

    container move1() override
    {
        return amnesia();
    }
    container move2() override
    {
        return thunderbolt(atk);
    }
    container move3() override
    {
        return psychic(atk);
    }
    container move4() override
    {
        return recover();
    }

    void print_moves() override
    {
        cout << "amnesia\n"
             << "thunderbolt\n"
             << "psychic\n"
             << "recover\n";
    }
};
