#include <iostream>
#include <string>
#include <vector>
#include "../BasePokemon.h"
#pragma once

using namespace std;

class Farfetch : public Pokemon
{
public:
    Farfetch()
    {
        (this->type).push_back("normal");
        (this->type).push_back("flying");
        this->name = "Farfetch'd";
        this->hp = 52;
        this->atk = 90;
        this->def = 55;
        this->sp_atk = 58;
        this->sp_def = 62;
        this->speed = 60;

        this->MyMove1_name = "agility";
        this->MyMove2_name = "slash";
        this->MyMove3_name = "swords_dance";
        this->MyMove3_name = "body_slam";
    };

    void speak() override
    {
        cout << name << endl;
    }

    container move1() override
    {
        return agility();
    }
    container move2() override
    {
        return slash(atk);
    }
    container move3() override
    {
        return swords_dance();
    }
    container move4() override
    {
        return body_slam(atk);
    }
    void print_moves() override
    {
        cout << "agility\n"
             << "slash\n"
             << "swords_dance\n"
             << "body_slam\n";
    }
};
