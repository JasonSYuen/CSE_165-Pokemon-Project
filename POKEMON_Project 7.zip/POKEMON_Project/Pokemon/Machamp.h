#include <iostream>
#include <string>
#include <vector>
#include "../BasePokemon.h"
#pragma once

using namespace std;

class Machamp : public Pokemon
{

public:
    Machamp()
    {
        (this->type).push_back("fighting");
        this->name = "Machamp";
        this->hp = 90;
        this->atk = 130;
        this->def = 80;
        this->sp_atk = 65;
        this->sp_def = 85;
        this->speed = 55;

        this->MyMove1_name = "submission";
        this->MyMove2_name = "earthquake";
        this->MyMove3_name = "body_slam";
        this->MyMove3_name = "hyper_beam";
    };

    void speak() override
    {
        cout << name << endl;
    }

    container move1() override
    {
        return submission(atk);
    }
    container move2() override
    {
        return earthquake(atk);
    }
    container move3() override
    {
        return body_slam(atk);
    }
    container move4() override
    {
        return hyper_beam(atk);
    }
    void print_moves() override
    {
        cout << "submission\n"
             << "earthquake\n"
             << "body_slam\n"
             << "hyper_beam\n";
    }
};
