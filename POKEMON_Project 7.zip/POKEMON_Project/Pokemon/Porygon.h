#include <iostream>
#include <string>
#include <vector>
#include "../BasePokemon.h"
#pragma once

using namespace std;

class Porygon : public Pokemon
{

public:
    Porygon()
    {
        (this->type).push_back("normal");
        this->name = "Porygon";
        this->hp = 65;
        this->atk = 60;
        this->def = 70;
        this->sp_atk = 85;
        this->sp_def = 75;
        this->speed = 40;

        this->MyMove1_name = "blizzard";
        this->MyMove2_name = "psychic";
        this->MyMove3_name = "thunder_wave";
        this->MyMove3_name = "recover";
    };

    void speak() override
    {
        cout << name << endl;
    }

    container move1() override
    {
        return blizzard(sp_atk);
    }
    container move2() override
    {
        return psychic(sp_atk);
    }
    container move3() override
    {
        return thunder_wave();
    }
    container move4() override
    {
        return recover();
    }
    void print_moves() override
    {
        cout << "blizzard\n"
             << "psychic\n"
             << "thunder_wave\n"
             << "recover\n";
    }
};
