#include <iostream>
#include <string>
#include <vector>
#include "../BasePokemon.h"

#pragma once

using namespace std;

class Arcanine : public Pokemon
{

public:
    Arcanine()
    {
        (this->type).push_back("fire");
        this->name = "Arcanine";
        this->hp = 90;
        this->atk = 110;
        this->def = 80;
        this->sp_atk = 100;
        this->sp_def = 80;
        this->speed = 95;
        this->MyMove1_name = "fire_blast";
        this->MyMove2_name = "hyper_beam";
        this->MyMove3_name = "body_slam";
        this->MyMove3_name = "flamethrower";
    };

    void speak() override
    {
        cout << name << endl;
    }

    container move1() override
    {
        return fire_blast(sp_atk);
    }
    container move2() override
    {
        return hyper_beam(atk);
    }
    container move3() override
    {
        return body_slam(atk);
    }
    container move4() override
    {
        return flamethrower(sp_atk);
    }

    void print_moves() override
    {
        cout << "fire blast\n"
             << "hyper beam\n"
             << "body slam\n"
             << "flamethrower\n";
    }
};
