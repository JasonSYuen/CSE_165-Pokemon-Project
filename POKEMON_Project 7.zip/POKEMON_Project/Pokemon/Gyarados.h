#include <iostream>
#include <string>
#include <vector>
#include "../BasePokemon.h"
#pragma once

using namespace std;

class Gyarados : public Pokemon
{

public:
    Gyarados()
    {
        (this->type).push_back("water");
        (this->type).push_back("flying");
        this->name = "Gyarados";
        this->hp = 95;
        this->atk = 125;
        this->def = 79;
        this->sp_atk = 60;
        this->sp_def = 100;
        this->speed = 81;

        this->MyMove1_name = "body_slam";
        this->MyMove2_name = "blizzard";
        this->MyMove3_name = "hydro_pump";
        this->MyMove3_name = "thunderbolt";
    };

    void speak() override
    {
        cout << name << endl;
    }
    container move1() override
    {
        return body_slam(atk);
    }
    container move2() override
    {
        return blizzard(sp_atk);
    }
    container move3() override
    {
        return hydro_pump(sp_atk);
    }
    container move4() override
    {
        return thunderbolt(atk);
    }

    void print_moves() override
    {
        cout << "body_slam\n"
             << "blizzard\n"
             << "hydro_pump\n"
             << "thunderbolt\n";
    }
};
