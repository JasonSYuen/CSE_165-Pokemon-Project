#include <iostream>
#include <string>
#include <vector>
#include "../BasePokemon.h"
#pragma once

using namespace std;

class Starmie : public Pokemon
{

public:
    Starmie()
    {
        (this->type).push_back("water");
        (this->type).push_back("psychic");
        this->name = "Starmie";
        this->hp = 60;
        this->atk = 75;
        this->def = 85;
        this->sp_atk = 100;
        this->sp_def = 85;
        this->speed = 115;

        this->MyMove1_name = "surf";
        this->MyMove2_name = "psychic";
        this->MyMove3_name = "thunder_wave";
        this->MyMove3_name = "recover";
    };

    void speak() override
    {
        cout << name << endl;
    }

    container move1() override
    {
        return surf(sp_atk);
    }
    container move2() override
    {
        return psychic(atk);
    }
    container move3() override
    {
        return thunder_wave();
    }
    container move4() override
    {
        return recover();
    }
    void print_moves() override
    {
        cout << "surf\n"
             << "psychic\n"
             << "thunder_wave\n"
             << "recover\n";
    }
};
