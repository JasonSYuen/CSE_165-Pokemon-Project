#include <iostream>
#include <string>
#include <vector>
#include "../BasePokemon.h"
#pragma once

using namespace std;

class Lapras : public Pokemon
{

public:
    Lapras()
    {
        (this->type).push_back("water");
        (this->type).push_back("ice");
        this->name = "Lapras";
        this->hp = 130;
        this->atk = 85;
        this->def = 80;
        this->sp_atk = 85;
        this->sp_def = 90;
        this->speed = 60;

        this->MyMove1_name = "sing";
        this->MyMove2_name = "thunderbolt";
        this->MyMove3_name = "blizzard";
        this->MyMove3_name = "hyper_beam";
    };

    void speak() override
    {
        cout << name << endl;
    }

    container move1() override
    {
        return sing();
    }
    container move2() override
    {
        return thunderbolt(sp_atk);
    }
    container move3() override
    {
        return blizzard(sp_atk);
    }
    container move4() override
    {
        return hyper_beam(atk);
    }

    void print_moves() override
    {
        cout << "sing\n"
             << "thunderbolt\n"
             << "blizzard\n"
             << "hyper_beam\n";
    }
};
