#include <iostream>
#include <string>
#include <vector>
#include "../BasePokemon.h"
#pragma once

using namespace std;

class Bulbasaur : public Pokemon
{

public:
    Bulbasaur()
    {
        (this->type).push_back("grass");
        this->name = "Bulbasaur";
        this->hp = 45;
        this->atk = 49;
        this->def = 49;
        this->sp_atk = 65;
        this->sp_def = 65;
        this->speed = 45;
        this->MyMove1_name = "swords_dance";
        this->MyMove2_name = "sleep";
        this->MyMove3_name = "razor_leaf";
        this->MyMove3_name = "body_slam";
    };

    void speak() override
    {
        cout << name << endl;
    }

    container move1() override
    {
        return swords_dance();
    }
    container move2() override
    {
        return sleep();
    }
    container move3() override
    {
        return razor_leaf(sp_atk);
    }
    container move4() override
    {
        return body_slam(atk);
    }

    void print_moves() override
    {
        cout << "swords dance\n"
             << "sleep\n"
             << "razor leaf\n"
             << "body slam\n";
    }
};

// 45	49	49	65	65	45