#include <iostream>
#include <string>
#include <vector>
#include "../BasePokemon.h"
#pragma once

using namespace std;

class Gengar : public Pokemon
{

public:
    Gengar()
    {
        (this->type).push_back("ghost");
        (this->type).push_back("poison");
        this->name = "Gengar";
        this->hp = 60;
        this->atk = 65;
        this->def = 60;
        this->sp_atk = 130;
        this->sp_def = 75;
        this->speed = 110;

        this->MyMove1_name = "hypnosis";
        this->MyMove2_name = "thunderbolt";
        this->MyMove3_name = "psychic";
        this->MyMove3_name = "explosion";
    };

    void speak() override
    {
        cout << name << endl;
    }

    container move1() override
    {
        return hypnosis();
    }
    container move2() override
    {
        return thunderbolt(sp_atk);
    }
    container move3() override
    {
        return psychic(sp_atk);
    }
    container move4() override
    {
        return explosion(atk);
    }

    void print_moves() override
    {
        cout << "hypnosis\n"
             << "thunderbolt\n"
             << "psychic\n"
             << "explosion\n";
    }
};
