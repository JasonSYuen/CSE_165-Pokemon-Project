#include <iostream>
using namespace std;
#include <vector>
#include <typeinfo>
#include "BasePokemon.h"
#pragma once
class menu
{

public:
    menu()
    {
    }

    void startGame()
    {
    }

    void Credits()
    {
    }
};
