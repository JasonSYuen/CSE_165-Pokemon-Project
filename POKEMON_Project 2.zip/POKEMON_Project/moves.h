#include <iostream>
#include <string>
#include <vector>
#include <stdlib.h>
using namespace std;

#pragma once

class moves
{
public:
    struct container
    {
        int total_attack_damage;
        string special_or_not;
        string damagetype;
        string status;
    };

    container fill_return_statement(int pp, int atk, string sp, string type, string effect)
    {
        container x;
        x.total_attack_damage = pp * atk;
        x.special_or_not = sp;
        x.damagetype = type;
        x.status = effect;
        return x;
    }
    // move 1

    container scratch(int atk)
    {
        // accuracy is 100 might need to make a random func later
        return fill_return_statement(40, atk, "physical", "normal", "none");
    }

    // move 2

    container sleep(int atk)
    {

        int x = rand() % 100 + 1;
        if (x > 25)
        {
            return fill_return_statement(0, atk, "physical", "normal", "sleep");
        }
        return fill_return_statement(0, atk, "physical", "normal", "miss");
    }
};