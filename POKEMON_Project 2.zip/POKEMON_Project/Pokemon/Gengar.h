#include <iostream>
#include <string>
#include <vector>
#include "../BasePokemon.h"
#include "../moves.h"
#pragma once

using namespace std;

class Gengar : public Pokemon, moves
{

public:
    Gengar()
    {
        (this->type).push_back("ghost");
        (this->type).push_back("poison");
        this->name = "Gengar";
        this->hp = 60;
        this->atk = 65;
        this->def = 60;
        this->sp_atk = 130;
        this->sp_def = 75;
        this->speed = 110;
    };

    void speak() override
    {
        cout << name << endl;
    }

    container move1()
    {
        return scratch(atk);
    }
};
